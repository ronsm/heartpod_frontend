# healthub
Python script, reads data from bluetooth health monitoring devices and store data in OpenHAB
